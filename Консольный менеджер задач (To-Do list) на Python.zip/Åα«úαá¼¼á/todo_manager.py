"""Точка входа консольного менеджера задач (итоговая работа, кейс № 7).

Запуск:
    python todo_manager.py
    python todo_manager.py --file data/tasks.json
    python todo_manager.py --no-color
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from todo.console import Console
from todo.errors import StorageError, ValidationError
from todo.models import DATE_FORMAT, Priority, Task
from todo.service import (
    SORT_DUE,
    SORT_LABELS,
    SORT_PRIORITY,
    SORT_STATUS,
    VIEW_ACTIVE,
    VIEW_ALL,
    VIEW_COMPLETED,
    VIEW_LABELS,
    VIEW_OVERDUE,
    TaskService,
)
from todo.storage import JsonStorage
from todo.validators import (
    parse_due_date,
    parse_priority,
    parse_task_id,
    validate_description,
    validate_query,
    validate_title,
)

MENU_ITEMS: Tuple[Tuple[str, str], ...] = (
    ("1", "Показать задачи"),
    ("2", "Добавить задачу"),
    ("3", "Отметить задачу выполненной"),
    ("4", "Удалить задачу"),
    ("5", "Найти задачу по слову"),
    ("6", "Экспорт задач в файл"),
    ("7", "Статистика"),
    ("0", "Выход"),
)

VIEW_CHOICES: Tuple[Tuple[str, str], ...] = (
    ("1", "все задачи"),
    ("2", "только активные"),
    ("3", "только выполненные"),
    ("4", "просроченные"),
)

SORT_CHOICES: Tuple[Tuple[str, str], ...] = (
    ("1", "по сроку выполнения (ближайшие сверху)"),
    ("2", "по приоритету (высокий -> низкий)"),
    ("3", "по статусу (активные перед выполненными)"),
)

VIEW_BY_KEY = {
    "1": VIEW_ALL,
    "2": VIEW_ACTIVE,
    "3": VIEW_COMPLETED,
    "4": VIEW_OVERDUE,
}

SORT_BY_KEY = {
    "1": SORT_DUE,
    "2": SORT_PRIORITY,
    "3": SORT_STATUS,
}

EXPORT_FORMATS = {
    "1": ("csv", "CSV (открывается в Excel)"),
    "2": ("txt", "TXT (простой текст)"),
}


class TodoApp:
    """Диалог с пользователем: меню и обработчики команд."""

    def __init__(self, service: TaskService, console: Console) -> None:
        self.service = service
        self.console = console
        self._banner_shown = False
        self._asked = False

    def run(self) -> int:
        """Основной цикл программы."""
        for warning in self.service.warnings:
            self.console.warning(warning)
        handlers = {
            "1": self.show_tasks,
            "2": self.add_task,
            "3": self.complete_task,
            "4": self.delete_task,
            "5": self.search_tasks,
            "6": self.export_tasks,
            "7": self.show_statistics,
        }
        while True:
            try:
                self._show_header()
                choice = self.console.ask(self._menu_prompt()).strip()
                self._asked = True
                if choice == "0":
                    self.console.write("")
                    self.console.success("Работа завершена. До встречи!")
                    return 0
                handler = handlers.get(choice)
                if handler is None:
                    self.console.error(
                        "пункта %s нет в меню: выберите число от 0 до 7"
                        % (choice or "(пусто)")
                    )
                    continue
                handler()
            except ValidationError as exc:
                self.console.error(str(exc))
            except StorageError as exc:
                self.console.error("ошибка файла: %s" % exc)
            except (KeyboardInterrupt, EOFError):
                self.console.write("")
                self.console.warning("Ввод прерван, работа завершена.")
                return 1

    def show_tasks(self) -> None:
        """Показать задачи с фильтром и сортировкой."""
        view = self._choose(VIEW_CHOICES, VIEW_BY_KEY, "Что показать?")
        sort_key = self._choose(SORT_CHOICES, SORT_BY_KEY, "Сортировка?")
        tasks = self.service.filter_tasks(view)
        ordered = self.service.sort_tasks(tasks, sort_key)
        self.console.heading("Список задач")
        self.console.write(
            "Фильтр: %s. Сортировка: %s."
            % (VIEW_LABELS[view], SORT_LABELS[sort_key])
        )
        self.console.task_table(ordered, date.today())
        overdue = sum(1 for task in ordered if task.is_overdue(date.today()))
        self.console.tasks_footer(
            len(ordered), len(self.service.all_tasks()), overdue
        )

    def add_task(self) -> None:
        """Добавить задачу."""
        self.console.heading("Новая задача")
        title = self._ask_until_valid("Название задачи: ", validate_title)
        description = self._ask_until_valid(
            "Описание (можно пропустить): ", validate_description
        )
        due = self._ask_until_valid(
            "Срок выполнения (ДД.ММ.ГГГГ): ", parse_due_date
        )
        self.console.write("Приоритет: 1 - высокий, 2 - средний, 3 - низкий")
        priority = self._ask_until_valid(
            "Приоритет [2]: ",
            lambda value: parse_priority(value.strip() or "2"),
        )
        task = self.service.add_task(title, description, due, priority)
        self.console.success(
            "Задача № %d добавлена: «%s» (срок %s, приоритет: %s)."
            % (
                task.id,
                task.title,
                task.due_date.strftime(DATE_FORMAT),
                task.priority.value,
            )
        )
        self.console.write(
            "    Изменения сохранены в %s." % self.service.storage_path.name
        )

    def complete_task(self) -> None:
        """Отметить задачу выполненной."""
        active = self.service.filter_tasks(VIEW_ACTIVE)
        if not active:
            self.console.warning("активных задач нет, выполнять нечего")
            return
        self.console.heading("Отметка задачи выполненной")
        self.console.task_table(
            self.service.sort_tasks(active, SORT_DUE), date.today()
        )
        task_id = self._ask_until_valid(
            "Номер задачи из колонки №: ", parse_task_id
        )
        task = self.service.complete_task(task_id)
        self.console.success(
            "Задача № %d «%s» отмечена выполненной." % (task.id, task.title)
        )
        self.console.write(
            "    Осталось активных задач: %d."
            % len(self.service.filter_tasks(VIEW_ACTIVE))
        )

    def delete_task(self) -> None:
        """Удалить задачу с подтверждением."""
        tasks = self.service.all_tasks()
        if not tasks:
            self.console.warning("список задач пуст, удалять нечего")
            return
        self.console.heading("Удаление задачи")
        self.console.task_table(
            self.service.sort_tasks(tasks, SORT_DUE), date.today()
        )
        task_id = self._ask_until_valid(
            "Номер задачи для удаления: ", parse_task_id
        )
        task = self.service.get(task_id)
        self.console.write("")
        self.console.warning(
            "Выбрана задача № %d: «%s» (срок %s, приоритет: %s)."
            % (
                task.id,
                task.title,
                task.due_date.strftime(DATE_FORMAT),
                task.priority.value,
            )
        )
        if not self.console.confirm("Удалить задачу безвозвратно?"):
            self.console.write("    Удаление отменено, список не изменён.")
            return
        self.service.delete_task(task_id)
        self.console.success(
            "Задача № %d удалена. Осталось задач: %d."
            % (task.id, len(self.service.all_tasks()))
        )

    def search_tasks(self) -> None:
        """Найти задачи по слову в названии или описании."""
        self.console.heading("Поиск задач")
        query = self._ask_until_valid("Ключевое слово: ", validate_query)
        found = self.service.search(query)
        if not found:
            self.console.warning(
                "по запросу «%s» ничего не найдено" % query
            )
            return
        self.console.task_table(
            self.service.sort_tasks(found, SORT_DUE), date.today()
        )
        self.console.tasks_footer(
            len(found),
            len(self.service.all_tasks()),
            sum(1 for task in found if task.is_overdue(date.today())),
        )

    def export_tasks(self) -> None:
        """Выгрузить задачи в CSV или TXT."""
        self.console.heading("Экспорт задач")
        if not self.service.all_tasks():
            self.console.warning("список задач пуст, экспортировать нечего")
            return
        self.console.submenu(
            [(key, text) for key, (_, text) in EXPORT_FORMATS.items()],
            "Формат файла:",
        )
        choice = self.console.ask("Формат [1]: ").strip() or "1"
        if choice not in EXPORT_FORMATS:
            raise ValidationError("выберите формат 1 (CSV) или 2 (TXT)")
        extension = EXPORT_FORMATS[choice][0]
        default_path = Path("export") / (
            "tasks_%s.%s" % (date.today().strftime("%Y%m%d"), extension)
        )
        raw_path = self.console.ask_default(
            "Путь к файлу [%s]: " % default_path, str(default_path)
        )
        if extension == "csv":
            target = self.service.export_csv(Path(raw_path))
        else:
            target = self.service.export_text(Path(raw_path))
        self.console.success(
            "Экспортировано задач: %d -> %s"
            % (len(self.service.all_tasks()), target)
        )

    def show_statistics(self) -> None:
        """Показать статистику по списку задач."""
        stats = self.service.statistics()
        self.console.statistics(stats)

    def _menu_prompt(self) -> str:
        """Приглашение: первый раз подробное, далее короткое."""
        if self._asked:
            return "Пункт меню (0 - выход): "
        return "Выберите пункт меню: "

    def _show_header(self) -> None:
        """Нарисовать шапку (один раз) и меню."""
        self.console.write("")
        if not self._banner_shown:
            tasks = self.service.all_tasks()
            active = sum(1 for task in tasks if task.is_active())
            self.console.banner(
                self.service.storage_path.name, len(tasks), active
            )
            self.console.menu(MENU_ITEMS)
            self._banner_shown = True

    def _choose(
        self,
        items: Sequence[Tuple[str, str]],
        mapping: Dict[str, str],
        title: str,
    ) -> str:
        """Показать подменю и вернуть выбранное значение."""
        self.console.submenu(items, title)
        key = self.console.ask_default("Ваш выбор [1]: ", "1")
        if key not in mapping:
            raise ValidationError(
                "неверный выбор: допустимо от 1 до %d" % len(mapping)
            )
        return mapping[key]

    def _ask_until_valid(self, prompt: str, validator: Any) -> Any:
        """Спрашивать значение, пока оно не пройдёт проверку."""
        while True:
            raw = self.console.ask(prompt)
            try:
                return validator(raw)
            except ValidationError as exc:
                self.console.error(str(exc))


def seed_tasks(service: TaskService) -> None:
    """Заполнить пустой список демонстрационными задачами."""
    today = date.today()
    samples = (
        ("Подготовить отчёт по ИА", "Собрать скриншоты", 3, "высокий"),
        ("Сдать тесты хранения", "Восстановление JSON", 5, "высокий"),
        ("Обновить README проекта", "Раздел про экспорт", 8, "средний"),
        ("Разобрать клавиатуру", "Почистить от пыли", 14, "низкий"),
    )
    for title, description, days, priority in samples:
        service.add_task(
            title,
            description,
            today + timedelta(days=days),
            parse_priority(priority),
        )


def build_parser() -> argparse.ArgumentParser:
    """Собрать парсер аргументов командной строки."""
    parser = argparse.ArgumentParser(
        prog="todo_manager",
        description="Консольный менеджер задач (To-Do list), кейс № 7.",
    )
    parser.add_argument(
        "-f",
        "--file",
        default="tasks.json",
        help="файл с задачами (по умолчанию tasks.json)",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="отключить цветной вывод",
    )
    parser.add_argument(
        "--seed",
        action="store_true",
        help="добавить демонстрационные задачи в пустой список",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="todo_manager 1.0.0",
    )
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """Точка входа: подготовить слои и запустить диалог."""
    args = build_parser().parse_args(argv)
    console = Console(color=False if args.no_color else None)
    storage = JsonStorage(Path(args.file))
    service = TaskService(storage)
    try:
        service.load()
    except StorageError as exc:
        console.error("не удалось загрузить задачи: %s" % exc)
        return 2
    if args.seed and not service.all_tasks():
        try:
            seed_tasks(service)
        except StorageError as exc:
            console.error("не удалось сохранить демо-задачи: %s" % exc)
            return 2
        console.info("Добавлены демонстрационные задачи.")
    return TodoApp(service, console).run()


if __name__ == "__main__":
    sys.exit(main())
