"""Модели предметной области консольного менеджера задач.

Модуль описывает структуру задачи, справочники приоритетов и статусов,
а также правила преобразования задачи в словарь и обратно. Он не зависит
от пользовательского интерфейса и от файловой системы.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from .errors import ValidationError

DATE_FORMAT = "%d.%m.%Y"
ISO_DATE_FORMAT = "%Y-%m-%d"
ISO_DATETIME_FORMAT = "%Y-%m-%dT%H:%M:%S"
MAX_TITLE_LENGTH = 100
MAX_DESCRIPTION_LENGTH = 500

PRIORITY_RANKS = {"высокий": 1, "средний": 2, "низкий": 3}


class Priority(str, Enum):
    """Приоритет задачи: чем меньше ранг, тем задача важнее."""

    HIGH = "высокий"
    MEDIUM = "средний"
    LOW = "низкий"

    @property
    def rank(self) -> int:
        """Числовой вес приоритета (1 — самый важный)."""
        return PRIORITY_RANKS[self.value]

    @classmethod
    def ordered(cls) -> List["Priority"]:
        """Вернуть приоритеты в порядке убывания важности."""
        return sorted(cls, key=lambda item: item.rank)


class Status(str, Enum):
    """Статус выполнения задачи."""

    ACTIVE = "active"
    COMPLETED = "completed"

    @property
    def label(self) -> str:
        """Название статуса для вывода пользователю."""
        return "активна" if self is Status.ACTIVE else "выполнена"


def _optional_datetime(value: Any, field_name: str) -> Optional[datetime]:
    """Разобрать необязательное поле с датой и временем."""
    if value is None or value == "":
        return None
    if not isinstance(value, str):
        raise ValidationError(
            "поле %s должно быть строкой с датой" % field_name
        )
    text = value.strip()
    for pattern in (ISO_DATETIME_FORMAT, "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, pattern)
        except ValueError:
            continue
    raise ValidationError(
        "поле %s содержит дату в неизвестном формате" % field_name
    )


def _parse_due_date(value: Any) -> date:
    """Разобрать срок выполнения из данных файла (ISO или ДД.ММ.ГГГГ)."""
    if not isinstance(value, str) or not value.strip():
        raise ValidationError(
            "поле due_date должно содержать дату в формате ГГГГ-ММ-ДД"
        )
    text = value.strip()
    for pattern in (ISO_DATE_FORMAT, DATE_FORMAT):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    raise ValidationError(
        "поле due_date содержит некорректную дату: %s" % text
    )


@dataclass
class Task:
    """Одна задача списка дел."""

    id: int
    title: str
    description: str = ""
    due_date: date = field(default_factory=date.today)
    priority: Priority = Priority.MEDIUM
    status: Status = Status.ACTIVE
    created_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None

    def is_active(self) -> bool:
        """Выполнена ли задача (активная задача ещё не выполнена)."""
        return self.status is Status.ACTIVE

    def is_overdue(self, today: Optional[date] = None) -> bool:
        """Просрочена ли активная задача."""
        current = today or date.today()
        return self.is_active() and self.due_date < current

    def days_left(self, today: Optional[date] = None) -> int:
        """Сколько дней осталось до срока (отрицательное — просрочка)."""
        current = today or date.today()
        return (self.due_date - current).days

    def to_dict(self) -> Dict[str, Any]:
        """Представить задачу в виде словаря для JSON-файла."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "due_date": self.due_date.strftime(ISO_DATE_FORMAT),
            "priority": self.priority.value,
            "status": self.status.value,
            "created_at": self.created_at.strftime(ISO_DATETIME_FORMAT),
            "completed_at": (
                self.completed_at.strftime(ISO_DATETIME_FORMAT)
                if self.completed_at
                else None
            ),
        }

    @classmethod
    def from_dict(cls, raw: Any) -> "Task":
        """Собрать задачу из словаря, полученного из JSON-файла."""
        if not isinstance(raw, dict):
            raise ValidationError("задача должна быть JSON-объектом")
        required = ("id", "title", "due_date")
        missing = [key for key in required if key not in raw]
        if missing:
            raise ValidationError(
                "в задаче отсутствуют поля: %s" % ", ".join(missing)
            )
        try:
            task_id = int(raw["id"])
        except (TypeError, ValueError) as exc:
            raise ValidationError(
                "идентификатор задачи должен быть целым числом"
            ) from exc
        if task_id <= 0:
            raise ValidationError(
                "идентификатор задачи должен быть положительным"
            )
        title = str(raw["title"]).strip()
        if not title:
            raise ValidationError("название задачи не может быть пустым")
        due_date = _parse_due_date(raw["due_date"])
        try:
            raw_priority = str(raw.get("priority", Priority.MEDIUM.value))
            raw_status = str(raw.get("status", Status.ACTIVE.value))
            priority = Priority(raw_priority)
            status = Status(raw_status)
        except ValueError as exc:
            raise ValidationError(
                "задача № %d содержит неизвестный приоритет или статус"
                % task_id
            ) from exc
        created_at = _optional_datetime(raw.get("created_at"), "created_at")
        completed_at = _optional_datetime(
            raw.get("completed_at"), "completed_at"
        )
        if status is Status.ACTIVE:
            completed_at = None
        elif completed_at is None:
            completed_at = datetime.now()
        return cls(
            id=task_id,
            title=title,
            description=str(raw.get("description", "")).strip(),
            due_date=due_date,
            priority=priority,
            status=status,
            created_at=created_at or datetime.now(),
            completed_at=completed_at,
        )
