"""Презентационный слой: цвета, таблицы и диалоги с пользователем.

Модуль не принимает решений о данных: он только показывает их и читает
ввод. Цвета включаются автоматически в терминале и отключаются при
перенаправлении вывода в файл (или флагом --no-color).
"""

from __future__ import annotations

import os
import sys
from datetime import date
from typing import Any, Dict, List, Optional, Sequence, Tuple

from .models import DATE_FORMAT, Priority, Task

RESET = "\033[0m"
BOLD = "\033[1m"
GREY = "\033[90m"
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BLUE = "\033[94m"

PRIORITY_COLORS = {
    Priority.HIGH: RED,
    Priority.MEDIUM: YELLOW,
    Priority.LOW: BLUE,
}

COLOR_ENV = "TODO_COLOR"
NO_COLOR_VALUES = {"0", "no", "false", "off"}
FORCE_COLOR_VALUES = {"1", "yes", "true", "on", "force"}


def enable_windows_ansi() -> None:
    """Разрешить ANSI-коды в консоли Windows 10 и новее."""
    if os.name != "nt":
        return
    try:
        import colorama

        colorama.just_fix_windows_console()
        return
    except ImportError:
        pass
    except Exception:
        return
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        return


class Console:
    """Вывод в консоль и чтение ответов пользователя."""

    HEADERS = ("№", "Срок", "Приоритет", "Статус", "Название")
    ALIGN = ("right", "left", "left", "left", "left")
    PRIORITY_COLUMN = 2
    STATUS_COLUMN = 3

    def __init__(
        self,
        stream: Optional[Any] = None,
        color: Optional[bool] = None,
    ) -> None:
        self.stream = stream or sys.stdout
        self._color = self._detect_color() if color is None else bool(color)
        if self._color:
            enable_windows_ansi()

    @staticmethod
    def _detect_color() -> bool:
        """Определить, нужно ли раскрашивать вывод."""
        setting = os.environ.get(COLOR_ENV, "").lower()
        if setting in NO_COLOR_VALUES:
            return False
        if setting in FORCE_COLOR_VALUES:
            return True
        try:
            return bool(sys.stdout.isatty())
        except (AttributeError, ValueError):
            return False

    @property
    def color_enabled(self) -> bool:
        """Включена ли раскраска."""
        return self._color

    def paint(self, text: str, *codes: str) -> str:
        """Раскрасить текст, если раскраска включена."""
        if not self._color or not codes:
            return text
        return "".join(codes) + text + RESET

    def write(self, text: str = "") -> None:
        """Вывести строку."""
        self.stream.write(text + "\n")
        self.stream.flush()

    def success(self, text: str) -> None:
        """Сообщение об успешной операции."""
        self.write(self.paint("[+] " + text, GREEN))

    def error(self, text: str) -> None:
        """Сообщение об ошибке."""
        self.write(self.paint("[!] " + text, RED))

    def warning(self, text: str) -> None:
        """Предупреждение."""
        self.write(self.paint("[~] " + text, YELLOW))

    def heading(self, text: str) -> None:
        """Заголовок раздела."""
        self.write("")
        self.write(self.paint(text, BOLD, CYAN))
        self.write(self.paint("-" * max(len(text), 24), GREY))

    def banner(
        self,
        path: Any,
        total: int,
        active: int,
        today: Optional[date] = None,
    ) -> None:
        """Шапка программы с краткой сводкой."""
        current = today or date.today()
        line = "=" * 62
        self.write(self.paint(line, GREY))
        self.write(
            "  "
            + self.paint("МЕНЕДЖЕР ЗАДАЧ (To-Do list)", BOLD, CYAN)
            + "   кейс № 7"
        )
        self.write(self.paint("  Файл данных: %s" % path, GREY))
        self.write(
            "  Сегодня: %s   всего задач: %d   активных: %d"
            % (current.strftime(DATE_FORMAT), total, active)
        )
        self.write(self.paint(line, GREY))

    def menu(self, items: Sequence[Tuple[str, str]]) -> None:
        """Показать меню с пунктами."""
        self.write("")
        self.write(self.paint("ГЛАВНОЕ МЕНЮ", BOLD, CYAN))
        for key, title in items:
            self.write("  %s. %s" % (self.paint(key, BOLD, CYAN), title))

    def submenu(self, items: Sequence[Tuple[str, str]], title: str) -> None:
        """Показать подменю выбора."""
        self.write("")
        self.write(self.paint(title, BOLD))
        for key, text in items:
            self.write("  %s - %s" % (self.paint(key, BOLD, CYAN), text))

    def task_table(self, tasks: List[Task], today: date) -> None:
        """Показать таблицу задач с цветовой индикацией."""
        if not tasks:
            self.warning("подходящих задач нет")
            return
        rows = [self._row(task) for task in tasks]
        widths = [len(header) for header in self.HEADERS]
        for row in rows:
            for index, cell in enumerate(row):
                widths[index] = max(widths[index], len(cell))
        header = " ".join(
            self._pad(self.HEADERS[index], widths[index], self.ALIGN[index])
            for index in range(len(self.HEADERS))
        ).rstrip()
        self.write(self.paint(header, BOLD, CYAN))
        self.write(self.paint("-" * len(header), GREY))
        for row, task in zip(rows, tasks):
            cells = []
            for index, cell in enumerate(row):
                padded = self._pad(cell, widths[index], self.ALIGN[index])
                codes = self._cell_codes(task, index, today)
                cells.append(self.paint(padded, *codes) if codes else padded)
            self.write(" ".join(cells).rstrip())

    def tasks_footer(self, shown: int, total: int, overdue: int) -> None:
        """Пояснение под таблицей задач."""
        note = "Показано задач: %d из %d." % (shown, total)
        if overdue:
            note += " Просрочено: %d (выделено красным)." % overdue
        self.write(self.paint(note, GREY))

    def statistics(self, stats: Dict[str, Any]) -> None:
        """Показать блок статистики."""
        self.heading("Статистика по задачам")
        lines = [
            ("Всего задач", "%d" % stats["total"]),
            ("Активных", "%d" % stats["active"]),
            ("Выполнено", "%d" % stats["completed"]),
            ("Просрочено", "%d" % stats["overdue"]),
            ("Высокий приоритет", "%d" % stats["by_priority"]["высокий"]),
            ("Средний приоритет", "%d" % stats["by_priority"]["средний"]),
            ("Низкий приоритет", "%d" % stats["by_priority"]["низкий"]),
        ]
        for label, value in lines:
            self.write("  %s %s" % (label.ljust(22, "."), value))
        self.write(
            "  %s %s"
            % (
                "Доля выполненных".ljust(22, "."),
                self.progress_bar(stats["completion_rate"]),
            )
        )
        nearest = stats.get("nearest")
        if nearest is not None:
            self.write(
                "  %s %s — %s"
                % (
                    "Ближайший срок".ljust(22, "."),
                    nearest.due_date.strftime(DATE_FORMAT),
                    nearest.title,
                )
            )

    @staticmethod
    def progress_bar(percent: float, width: int = 20) -> str:
        """Нарисовать текстовый индикатор выполнения."""
        filled = int(round(percent / 100 * width))
        filled = min(max(filled, 0), width)
        return "[%s%s] %5.1f %%" % (
            "#" * filled,
            "." * (width - filled),
            percent,
        )

    def ask(self, prompt: str) -> str:
        """Прочитать строку ввода, выделив приглашение."""
        if self._color:
            return input(self.paint(prompt, BOLD))
        return input(prompt)

    def ask_default(self, prompt: str, default: str) -> str:
        """Прочитать строку, подставив значение по умолчанию."""
        answer = self.ask(prompt).strip()
        return answer or default

    def confirm(self, question: str) -> bool:
        """Задать вопрос с ответом «да/нет»."""
        answer = self.ask("%s [y/N]: " % question).strip().lower()
        return answer in {"y", "yes", "д", "да"}

    @staticmethod
    def _pad(text: str, width: int, align: str) -> str:
        """Дополнить текст пробелами до нужной ширины."""
        if align == "right":
            return text.rjust(width)
        return text.ljust(width)

    @staticmethod
    def _row(task: Task) -> List[str]:
        """Строка таблицы для одной задачи."""
        return [
            str(task.id),
            task.due_date.strftime(DATE_FORMAT),
            task.priority.value,
            task.status.label,
            task.title,
        ]

    @staticmethod
    def _cell_codes(task: Task, index: int, today: date) -> Tuple[str, ...]:
        """Цвет ячейки: просроченные задачи выделены целиком."""
        if task.is_overdue(today):
            return (RED,)
        if not task.is_active():
            return (GREEN,)
        if index == Console.PRIORITY_COLUMN:
            return (PRIORITY_COLORS[task.priority],)
        if index == Console.STATUS_COLUMN:
            return (GREEN,)
        return ()
