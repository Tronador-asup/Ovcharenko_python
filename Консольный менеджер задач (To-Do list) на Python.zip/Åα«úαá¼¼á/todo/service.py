"""Бизнес-логика: добавление, выполнение, удаление, фильтры, экспорт."""

from __future__ import annotations

import csv
from dataclasses import replace
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .errors import StorageError, ValidationError
from .models import DATE_FORMAT, ISO_DATETIME_FORMAT, Priority, Status, Task
from .storage import JsonStorage

VIEW_ALL = "all"
VIEW_ACTIVE = "active"
VIEW_COMPLETED = "completed"
VIEW_OVERDUE = "overdue"

SORT_DUE = "due"
SORT_PRIORITY = "priority"
SORT_STATUS = "status"

VIEW_LABELS = {
    VIEW_ALL: "все задачи",
    VIEW_ACTIVE: "только активные",
    VIEW_COMPLETED: "только выполненные",
    VIEW_OVERDUE: "просроченные",
}

SORT_LABELS = {
    SORT_DUE: "по сроку выполнения",
    SORT_PRIORITY: "по приоритету",
    SORT_STATUS: "по статусу",
}

SORT_KEYS: Dict[str, Callable[[Task], Any]] = {
    SORT_DUE: lambda task: (task.due_date, task.priority.rank, task.id),
    SORT_PRIORITY: lambda task: (task.priority.rank, task.due_date, task.id),
    SORT_STATUS: lambda task: (
        0 if task.is_active() else 1,
        task.due_date,
        task.id,
    ),
}

CSV_HEADER = (
    "№",
    "Название",
    "Описание",
    "Срок",
    "Приоритет",
    "Статус",
    "Создана",
    "Выполнена",
)


class TaskService:
    """Операции над списком задач с сохранением после каждого изменения."""

    def __init__(self, storage: JsonStorage) -> None:
        self._storage = storage
        self._tasks: List[Task] = []
        self._warnings: List[str] = []

    @property
    def storage_path(self) -> Path:
        """Путь к файлу, в котором хранятся задачи."""
        return self._storage.path

    @property
    def warnings(self) -> List[str]:
        """Предупреждения, полученные при загрузке файла."""
        return list(self._warnings)

    def load(self) -> None:
        """Загрузить задачи из файла."""
        self._tasks = self._storage.load()
        self._warnings = self._storage.warnings

    def all_tasks(self) -> List[Task]:
        """Вернуть копию списка задач."""
        return list(self._tasks)

    def get(self, task_id: int) -> Task:
        """Найти задачу по номеру."""
        for task in self._tasks:
            if task.id == task_id:
                return task
        raise ValidationError("задача № %d не найдена" % task_id)

    def add_task(
        self,
        title: str,
        description: str,
        due_date: date,
        priority: Priority,
    ) -> Task:
        """Создать задачу и сразу сохранить список."""
        task = Task(
            id=self._next_id(),
            title=title,
            description=description,
            due_date=due_date,
            priority=priority,
        )
        self._commit(self._tasks + [task])
        return task

    def complete_task(self, task_id: int) -> Task:
        """Отметить задачу выполненной."""
        task = self.get(task_id)
        if not task.is_active():
            raise ValidationError("задача № %d уже выполнена" % task_id)
        updated = replace(
            task, status=Status.COMPLETED, completed_at=datetime.now()
        )
        self._commit(self._replace(task_id, updated))
        return updated

    def delete_task(self, task_id: int) -> Task:
        """Удалить задачу из списка."""
        task = self.get(task_id)
        remaining = [item for item in self._tasks if item.id != task_id]
        self._commit(remaining)
        return task

    def filter_tasks(
        self, view: str, today: Optional[date] = None
    ) -> List[Task]:
        """Отобрать задачи по выбранному представлению."""
        if view == VIEW_ALL:
            return list(self._tasks)
        if view == VIEW_ACTIVE:
            return [task for task in self._tasks if task.is_active()]
        if view == VIEW_COMPLETED:
            return [task for task in self._tasks if not task.is_active()]
        if view == VIEW_OVERDUE:
            return [task for task in self._tasks if task.is_overdue(today)]
        raise ValueError("неизвестное представление: %s" % view)

    def sort_tasks(self, tasks: List[Task], sort_key: str) -> List[Task]:
        """Отсортировать задачи по сроку, приоритету или статусу."""
        if sort_key not in SORT_KEYS:
            raise ValueError("неизвестный ключ сортировки: %s" % sort_key)
        return sorted(tasks, key=SORT_KEYS[sort_key])

    def search(self, query: str) -> List[Task]:
        """Найти задачи по слову в названии или описании."""
        needle = query.strip().lower()
        if not needle:
            raise ValidationError("поисковый запрос не может быть пустым")
        return [
            task
            for task in self._tasks
            if needle in task.title.lower()
            or needle in task.description.lower()
        ]

    def statistics(self, today: Optional[date] = None) -> Dict[str, Any]:
        """Собрать статистику по списку задач."""
        current = today or date.today()
        total = len(self._tasks)
        completed = sum(1 for task in self._tasks if not task.is_active())
        active = total - completed
        overdue = sum(1 for task in self._tasks if task.is_overdue(current))
        by_priority = {
            priority.value: sum(
                1 for task in self._tasks if task.priority is priority
            )
            for priority in Priority.ordered()
        }
        active_tasks = [task for task in self._tasks if task.is_active()]
        rate = round(completed * 100 / total, 1) if total else 0.0
        nearest = min(
            active_tasks,
            key=lambda task: (task.due_date, task.id),
            default=None,
        )
        return {
            "total": total,
            "active": active,
            "completed": completed,
            "overdue": overdue,
            "by_priority": by_priority,
            "nearest": nearest,
            "completion_rate": rate,
            "today": current,
        }

    def export_csv(self, path: Path) -> Path:
        """Выгрузить задачи в CSV-файл (разделитель «;», кодировка UTF-8)."""
        target = Path(path)
        ordered = self.sort_tasks(self._tasks, SORT_DUE)
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with open(target, "w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.writer(handle, delimiter=";")
                writer.writerow(CSV_HEADER)
                for number, task in enumerate(ordered, 1):
                    writer.writerow(self._csv_row(number, task))
        except OSError as exc:
            raise StorageError(
                "не удалось записать файл %s (%s)" % (target, exc.strerror)
            ) from exc
        return target

    def export_text(self, path: Path) -> Path:
        """Выгрузить задачи в текстовый файл."""
        target = Path(path)
        ordered = self.sort_tasks(self._tasks, SORT_DUE)
        lines = [
            "Список задач на %s" % date.today().strftime(DATE_FORMAT),
            "=" * 62,
        ]
        for number, task in enumerate(ordered, 1):
            lines.append(
                "%2d. [%s] %s  %-8s %s"
                % (
                    number,
                    task.status.label,
                    task.due_date.strftime(DATE_FORMAT),
                    task.priority.value,
                    task.title,
                )
            )
            if task.description:
                lines.append("    " + task.description)
            if task.completed_at:
                lines.append(
                    "    выполнена: %s"
                    % task.completed_at.strftime(DATE_FORMAT)
                )
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with open(target, "w", encoding="utf-8", newline="\n") as handle:
                handle.write("\n".join(lines) + "\n")
        except OSError as exc:
            raise StorageError(
                "не удалось записать файл %s (%s)" % (target, exc.strerror)
            ) from exc
        return target

    def _commit(self, tasks: List[Task]) -> None:
        """Сохранить список в файл, затем обновить состояние в памяти."""
        self._storage.save(tasks)
        self._tasks = list(tasks)

    def _replace(self, task_id: int, updated: Task) -> List[Task]:
        """Заменить одну задачу в копии списка."""
        return [
            updated if task.id == task_id else task for task in self._tasks
        ]

    def _next_id(self) -> int:
        """Следующий свободный номер задачи."""
        if not self._tasks:
            return 1
        return max(task.id for task in self._tasks) + 1

    @staticmethod
    def _csv_row(number: int, task: Task) -> List[str]:
        """Строка CSV-файла для одной задачи."""
        return [
            str(number),
            task.title,
            task.description,
            task.due_date.strftime(DATE_FORMAT),
            task.priority.value,
            task.status.label,
            task.created_at.strftime("%d.%m.%Y %H:%M"),
            (
                task.completed_at.strftime("%d.%m.%Y %H:%M")
                if task.completed_at
                else ""
            ),
        ]
