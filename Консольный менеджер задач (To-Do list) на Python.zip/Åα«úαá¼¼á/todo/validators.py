"""Валидация данных, которые вводит пользователь.

Все проверки собраны в одном модуле: это позволяет тестировать их
отдельно от интерфейса и переиспользовать в разных местах программы.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional

from .errors import ValidationError
from .models import (
    DATE_FORMAT,
    MAX_DESCRIPTION_LENGTH,
    MAX_TITLE_LENGTH,
    Priority,
)

DATE_PATTERN = re.compile(r"^\d{2}\.\d{2}\.\d{4}$")
MIN_TITLE_LENGTH = 2
MIN_QUERY_LENGTH = 2

PRIORITY_ALIASES = {
    "1": Priority.HIGH,
    "высокий": Priority.HIGH,
    "высокая": Priority.HIGH,
    "high": Priority.HIGH,
    "2": Priority.MEDIUM,
    "средний": Priority.MEDIUM,
    "средняя": Priority.MEDIUM,
    "medium": Priority.MEDIUM,
    "3": Priority.LOW,
    "низкий": Priority.LOW,
    "низкая": Priority.LOW,
    "low": Priority.LOW,
}


def normalise_spaces(raw: str) -> str:
    """Убрать лишние пробелы и переводы строк из введённого текста."""
    return " ".join(str(raw or "").split())


def validate_title(raw: str) -> str:
    """Проверить название задачи."""
    title = normalise_spaces(raw)
    if not title:
        raise ValidationError("название задачи не может быть пустым")
    if len(title) < MIN_TITLE_LENGTH:
        raise ValidationError(
            "название задачи слишком короткое (минимум %d символа)"
            % MIN_TITLE_LENGTH
        )
    if len(title) > MAX_TITLE_LENGTH:
        raise ValidationError(
            "название задачи длиннее %d символов" % MAX_TITLE_LENGTH
        )
    return title


def validate_description(raw: str) -> str:
    """Проверить описание задачи (поле необязательное)."""
    description = normalise_spaces(raw)
    if len(description) > MAX_DESCRIPTION_LENGTH:
        raise ValidationError(
            "описание длиннее %d символов" % MAX_DESCRIPTION_LENGTH
        )
    return description


def parse_due_date(raw: str, today: Optional[date] = None) -> date:
    """Разобрать срок выполнения в формате ДД.ММ.ГГГГ."""
    current = today or date.today()
    text = str(raw or "").strip()
    if not text:
        raise ValidationError("срок выполнения не может быть пустым")
    if not DATE_PATTERN.match(text):
        raise ValidationError(
            "дата должна быть в формате ДД.ММ.ГГГГ, например 15.11.2026"
        )
    try:
        parsed = datetime.strptime(text, DATE_FORMAT).date()
    except ValueError as exc:
        raise ValidationError("даты %s не существует" % text) from exc
    if parsed < current:
        raise ValidationError(
            "срок не может быть раньше сегодняшнего дня (%s)"
            % current.strftime(DATE_FORMAT)
        )
    if parsed.year > current.year + 20:
        raise ValidationError(
            "слишком далёкий срок: укажите дату не позже %d года"
            % (current.year + 20)
        )
    return parsed


def parse_priority(raw: str) -> Priority:
    """Разобрать приоритет словами или числом (1, 2, 3)."""
    text = normalise_spaces(raw).lower()
    if not text:
        raise ValidationError("укажите приоритет: 1, 2 или 3")
    if text not in PRIORITY_ALIASES:
        raise ValidationError(
            "приоритет выбирается из списка: высокий, средний, низкий"
        )
    return PRIORITY_ALIASES[text]


def parse_task_id(raw: str) -> int:
    """Разобрать номер задачи."""
    text = str(raw or "").strip()
    if not text:
        raise ValidationError("укажите номер задачи из списка")
    if not text.isdigit():
        raise ValidationError("номер задачи должен быть целым числом")
    return int(text)


def validate_query(raw: str) -> str:
    """Проверить поисковый запрос."""
    query = normalise_spaces(raw)
    if len(query) < MIN_QUERY_LENGTH:
        raise ValidationError(
            "поисковый запрос должен содержать минимум %d символа"
            % MIN_QUERY_LENGTH
        )
    return query
