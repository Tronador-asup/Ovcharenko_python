"""Сохранение задач в JSON-файл и восстановление после сбоев.

Слой хранения отвечает только за файл: он не знает о меню и о том, как
задачи отображаются. Запись выполняется атомарно (временный файл плюс
os.replace), поэтому сбой не оставит «половину» файла.
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .errors import StorageError, ValidationError
from .models import Task

SCHEMA_VERSION = 1
BACKUP_SUFFIX = "corrupted"


class JsonStorage:
    """Чтение и запись списка задач в JSON-файл."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.warnings: List[str] = []

    def load(self) -> List[Task]:
        """Загрузить задачи. Отсутствие файла — это пустой список."""
        self.warnings = []
        if not self.path.exists():
            return []
        raw = self._read_text()
        if not raw.strip():
            self.warnings.append(
                "Файл %s пуст, начат новый список задач." % self.path.name
            )
            return []
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            return self._recover(
                "повреждён: некорректный JSON (строка %d)" % exc.lineno
            )
        records = self._extract_records(payload)
        if records is None:
            return self._recover("имеет неизвестную структуру")
        tasks: List[Task] = []
        for record in records:
            try:
                tasks.append(Task.from_dict(record))
            except ValidationError as exc:
                return self._recover("содержит ошибку: %s" % exc)
        return tasks

    def save(self, tasks: List[Task]) -> None:
        """Атомарно сохранить задачи в файл."""
        payload: Dict[str, Any] = {
            "version": SCHEMA_VERSION,
            "saved_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "tasks": [task.to_dict() for task in tasks],
        }
        data = json.dumps(payload, ensure_ascii=False, indent=2)
        temporary = self.path.with_name(self.path.name + ".tmp")
        try:
            if self.path.parent != Path(""):
                self.path.parent.mkdir(parents=True, exist_ok=True)
            with open(
                temporary, "w", encoding="utf-8", newline="\n"
            ) as handle:
                handle.write(data + "\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.path)
        except OSError as exc:
            self._cleanup(temporary)
            raise StorageError(
                "не удалось сохранить задачи в %s (%s)"
                % (self.path, self._describe_os_error(exc))
            ) from exc

    def _read_text(self) -> str:
        """Прочитать файл, превратив ошибки доступа в понятный текст."""
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                return handle.read()
        except OSError as exc:
            raise StorageError(
                "не удалось прочитать %s (%s)"
                % (self.path, self._describe_os_error(exc))
            ) from exc

    @staticmethod
    def _extract_records(payload: Any) -> Optional[List[Any]]:
        """Достать список задач из файла (поддерживаются две структуры)."""
        if isinstance(payload, list):
            return payload
        if isinstance(payload, dict):
            tasks = payload.get("tasks")
            if isinstance(tasks, list):
                return tasks
        return None

    def _recover(self, reason: str) -> List[Task]:
        """Сохранить копию плохого файла и продолжить с пустым списком."""
        backup = self._backup_name()
        note = ""
        try:
            shutil.copy2(self.path, backup)
            note = " Копия сохранена как %s." % backup.name
        except OSError:
            note = " Копию создать не удалось."
        self.warnings.append(
            "Файл %s %s.%s Начат новый список задач."
            % (self.path.name, reason, note)
        )
        return []

    def _backup_name(self) -> Path:
        """Имя файла для копии повреждённых данных."""
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        return self.path.with_name(
            "%s.%s-%s" % (self.path.name, BACKUP_SUFFIX, stamp)
        )

    @staticmethod
    def _cleanup(path: Path) -> None:
        """Удалить временный файл, если он остался после ошибки."""
        try:
            if path.exists():
                path.unlink()
        except OSError:
            pass

    @staticmethod
    def _describe_os_error(exc: OSError) -> str:
        """Короткое пояснение ошибки файловой системы."""
        if isinstance(exc, PermissionError):
            return "нет прав на запись в этот файл или папку"
        if isinstance(exc, FileNotFoundError):
            return "путь не существует"
        return exc.strerror or str(exc)
