"""Тесты валидации пользовательского ввода."""

import unittest
from datetime import date, timedelta

from todo.errors import ValidationError
from todo.models import Priority
from todo.validators import (
    normalise_spaces,
    parse_due_date,
    parse_priority,
    parse_task_id,
    validate_description,
    validate_query,
    validate_title,
)


class TitleValidationTest(unittest.TestCase):
    """Проверки названия задачи."""

    def test_extra_spaces_are_collapsed(self):
        self.assertEqual(
            validate_title("  Оплатить   интернет  "), "Оплатить интернет"
        )

    def test_empty_title_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_title("   ")

    def test_too_short_title_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_title("я")

    def test_too_long_title_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_title("а" * 101)

    def test_normalise_spaces_keeps_single_spaces(self):
        self.assertEqual(normalise_spaces(" a  b "), "a b")


class DescriptionValidationTest(unittest.TestCase):
    """Проверки описания задачи."""

    def test_description_is_optional(self):
        self.assertEqual(validate_description(""), "")

    def test_long_description_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_description("а" * 501)


class DueDateValidationTest(unittest.TestCase):
    """Проверки срока выполнения."""

    def test_future_date_is_accepted(self):
        today = date(2026, 11, 9)
        self.assertEqual(
            parse_due_date("15.11.2026", today), date(2026, 11, 15)
        )

    def test_today_is_accepted(self):
        today = date(2026, 11, 9)
        self.assertEqual(parse_due_date("09.11.2026", today), today)

    def test_past_date_is_rejected(self):
        today = date(2026, 11, 9)
        with self.assertRaises(ValidationError):
            parse_due_date("08.11.2026", today)

    def test_yesterday_relative_to_today_is_rejected(self):
        today = date(2026, 11, 9)
        yesterday = today - timedelta(days=1)
        with self.assertRaises(ValidationError):
            parse_due_date(yesterday.strftime("%d.%m.%Y"), today)

    def test_wrong_separator_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_due_date("2026-11-15")

    def test_impossible_date_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_due_date("31.02.2026")

    def test_empty_date_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_due_date("")

    def test_too_far_date_is_rejected(self):
        today = date(2026, 11, 9)
        with self.assertRaises(ValidationError):
            parse_due_date("01.01.2060", today)


class PriorityValidationTest(unittest.TestCase):
    """Проверки приоритета."""

    def test_priority_by_number(self):
        self.assertEqual(parse_priority("1"), Priority.HIGH)
        self.assertEqual(parse_priority("2"), Priority.MEDIUM)
        self.assertEqual(parse_priority("3"), Priority.LOW)

    def test_priority_by_word(self):
        self.assertEqual(parse_priority("высокий"), Priority.HIGH)

    def test_priority_is_case_insensitive(self):
        self.assertEqual(parse_priority("  НИЗКИЙ "), Priority.LOW)

    def test_priority_accepts_english_words(self):
        self.assertEqual(parse_priority("medium"), Priority.MEDIUM)

    def test_unknown_priority_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_priority("4")

    def test_empty_priority_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_priority("")


class TaskIdValidationTest(unittest.TestCase):
    """Проверки номера задачи."""

    def test_number_is_parsed(self):
        self.assertEqual(parse_task_id(" 12 "), 12)

    def test_text_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_task_id("первая")

    def test_empty_number_is_rejected(self):
        with self.assertRaises(ValidationError):
            parse_task_id("")


class QueryValidationTest(unittest.TestCase):
    """Проверки поискового запроса."""

    def test_query_is_normalised(self):
        self.assertEqual(validate_query("  отчёт "), "отчёт")

    def test_short_query_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_query("a")


if __name__ == "__main__":
    unittest.main()
