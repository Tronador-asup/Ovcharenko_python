"""Тесты бизнес-логики: CRUD, фильтры, сортировка, поиск, экспорт."""

import csv
import unittest
from datetime import date, timedelta
from pathlib import Path

from tests.support import make_temp_folder, remove_folder

from todo.errors import ValidationError
from todo.models import Priority, Status, Task
from todo.service import (
    SORT_DUE,
    SORT_PRIORITY,
    SORT_STATUS,
    VIEW_ACTIVE,
    VIEW_ALL,
    VIEW_COMPLETED,
    VIEW_OVERDUE,
    TaskService,
)
from todo.storage import JsonStorage

TODAY = date(2026, 11, 9)


class ServiceTestCase(unittest.TestCase):
    """Базовый класс: сервис с временным файлом."""

    def setUp(self):
        self.folder = make_temp_folder("todo-service-")
        self.addCleanup(remove_folder, self.folder)
        self.path = self.folder / "tasks.json"
        self.service = self._new_service()

    def _new_service(self):
        service = TaskService(JsonStorage(self.path))
        service.load()
        return service

    def fill(self):
        """Создать три задачи с разными свойствами."""
        first = self.service.add_task(
            "Сдать отчёт", "Итоговая работа", TODAY, Priority.HIGH
        )
        second = self.service.add_task(
            "Купить продукты", "Молоко и хлеб", TODAY + timedelta(days=5),
            Priority.LOW,
        )
        third = self.service.add_task(
            "Позвонить куратору", "Уточнить дату защиты",
            TODAY + timedelta(days=2), Priority.MEDIUM,
        )
        return first, second, third


class AddTaskTest(ServiceTestCase):
    """Добавление задач."""

    def test_ids_grow(self):
        self.fill()
        self.assertEqual([task.id for task in self.service.all_tasks()],
                         [1, 2, 3])

    def test_new_task_is_saved_to_file(self):
        self.service.add_task("Тест", "", TODAY, Priority.MEDIUM)
        self.assertTrue(self.path.exists())
        reloaded = self._new_service()
        self.assertEqual(len(reloaded.all_tasks()), 1)

    def test_task_fields_are_kept(self):
        task = self.service.add_task(
            "Тест", "Описание", TODAY + timedelta(days=1), Priority.HIGH
        )
        self.assertEqual(task.title, "Тест")
        self.assertEqual(task.description, "Описание")
        self.assertTrue(task.is_active())

    def test_id_continues_after_delete(self):
        first, second, _ = self.fill()
        self.service.delete_task(first.id)
        new_task = self.service.add_task("Новая", "", TODAY, Priority.LOW)
        self.assertEqual(new_task.id, 4)
        self.assertEqual(second.id, 2)


class CompleteTaskTest(ServiceTestCase):
    """Отметка задачи выполненной."""

    def test_status_and_time_are_set(self):
        task = self.service.add_task("Тест", "", TODAY, Priority.MEDIUM)
        updated = self.service.complete_task(task.id)
        self.assertFalse(updated.is_active())
        self.assertIsNotNone(updated.completed_at)

    def test_result_is_saved(self):
        task = self.service.add_task("Тест", "", TODAY, Priority.MEDIUM)
        self.service.complete_task(task.id)
        reloaded = self._new_service()
        self.assertFalse(reloaded.all_tasks()[0].is_active())

    def test_repeated_completion_is_rejected(self):
        task = self.service.add_task("Тест", "", TODAY, Priority.MEDIUM)
        self.service.complete_task(task.id)
        with self.assertRaises(ValidationError):
            self.service.complete_task(task.id)

    def test_unknown_id_is_rejected(self):
        with self.assertRaises(ValidationError):
            self.service.complete_task(99)


class DeleteTaskTest(ServiceTestCase):
    """Удаление задач."""

    def test_task_is_removed(self):
        task = self.service.add_task("Тест", "", TODAY, Priority.MEDIUM)
        deleted = self.service.delete_task(task.id)
        self.assertEqual(deleted.id, 1)
        self.assertEqual(self.service.all_tasks(), [])

    def test_deletion_is_saved(self):
        task = self.service.add_task("Тест", "", TODAY, Priority.MEDIUM)
        self.service.delete_task(task.id)
        self.assertEqual(self._new_service().all_tasks(), [])

    def test_unknown_id_is_rejected(self):
        with self.assertRaises(ValidationError):
            self.service.delete_task(42)


class FilterTest(ServiceTestCase):
    """Фильтрация задач."""

    def test_all_view_returns_everything(self):
        self.fill()
        self.assertEqual(len(self.service.filter_tasks(VIEW_ALL)), 3)

    def test_active_view(self):
        first, _, _ = self.fill()
        self.service.complete_task(first.id)
        active = self.service.filter_tasks(VIEW_ACTIVE)
        self.assertEqual(len(active), 2)

    def test_completed_view(self):
        first, _, _ = self.fill()
        self.service.complete_task(first.id)
        completed = self.service.filter_tasks(VIEW_COMPLETED)
        self.assertEqual([task.id for task in completed], [1])

    def test_overdue_view(self):
        task = self.service.add_task("Старая", "", TODAY, Priority.LOW)
        task.due_date = TODAY - timedelta(days=1)
        overdue = self.service.filter_tasks(VIEW_OVERDUE, TODAY)
        self.assertEqual(len(overdue), 1)

    def test_unknown_view_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.filter_tasks("unknown")


class SortTest(ServiceTestCase):
    """Сортировка задач."""

    def test_sort_by_due_date(self):
        self.fill()
        ordered = self.service.sort_tasks(self.service.all_tasks(), SORT_DUE)
        self.assertEqual([task.id for task in ordered], [1, 3, 2])

    def test_sort_by_priority(self):
        self.fill()
        ordered = self.service.sort_tasks(
            self.service.all_tasks(), SORT_PRIORITY
        )
        self.assertEqual([task.priority for task in ordered],
                         [Priority.HIGH, Priority.MEDIUM, Priority.LOW])

    def test_sort_by_status(self):
        first, second, _ = self.fill()
        self.service.complete_task(second.id)
        ordered = self.service.sort_tasks(
            self.service.all_tasks(), SORT_STATUS
        )
        self.assertTrue(ordered[0].is_active())
        self.assertFalse(ordered[-1].is_active())

    def test_unknown_sort_key_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.sort_tasks([], "unknown")


class SearchTest(ServiceTestCase):
    """Поиск задач."""

    def test_search_by_title(self):
        self.fill()
        found = self.service.search("отчёт")
        self.assertEqual(len(found), 1)

    def test_search_is_case_insensitive(self):
        self.fill()
        self.assertEqual(len(self.service.search("ОТЧЁТ")), 1)

    def test_search_by_description(self):
        self.fill()
        found = self.service.search("молоко")
        self.assertEqual(found[0].title, "Купить продукты")

    def test_empty_query_is_rejected(self):
        with self.assertRaises(ValidationError):
            self.service.search("   ")

    def test_nothing_found(self):
        self.fill()
        self.assertEqual(self.service.search("автомобиль"), [])


class StatisticsTest(ServiceTestCase):
    """Статистика."""

    def test_counters(self):
        first, _, _ = self.fill()
        self.service.complete_task(first.id)
        stats = self.service.statistics(TODAY)
        self.assertEqual(stats["total"], 3)
        self.assertEqual(stats["active"], 2)
        self.assertEqual(stats["completed"], 1)

    def test_completion_rate(self):
        first, second, _ = self.fill()
        self.service.complete_task(first.id)
        self.service.complete_task(second.id)
        stats = self.service.statistics(TODAY)
        self.assertAlmostEqual(stats["completion_rate"], 66.7, places=1)

    def test_priority_counters(self):
        self.fill()
        stats = self.service.statistics(TODAY)
        self.assertEqual(stats["by_priority"]["высокий"], 1)
        self.assertEqual(stats["by_priority"]["средний"], 1)
        self.assertEqual(stats["by_priority"]["низкий"], 1)

    def test_nearest_task(self):
        self.fill()
        stats = self.service.statistics(TODAY)
        self.assertEqual(stats["nearest"].title, "Сдать отчёт")

    def test_empty_list_statistics(self):
        stats = self.service.statistics(TODAY)
        self.assertEqual(stats["total"], 0)
        self.assertIsNone(stats["nearest"])


class ExportTest(ServiceTestCase):
    """Экспорт задач."""

    def test_csv_export(self):
        self.fill()
        target = self.service.export_csv(self.folder / "export" / "tasks.csv")
        self.assertTrue(target.exists())
        with open(target, encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.reader(handle, delimiter=";"))
        self.assertEqual(len(rows), 4)
        self.assertEqual(rows[0][1], "Название")

    def test_text_export(self):
        self.fill()
        target = self.service.export_text(self.folder / "tasks.txt")
        text = target.read_text(encoding="utf-8")
        self.assertIn("Сдать отчёт", text)

    def test_export_creates_folder(self):
        self.fill()
        target = self.service.export_csv(self.folder / "a" / "b" / "tasks.csv")
        self.assertTrue(target.exists())


class OverdueTest(unittest.TestCase):
    """Правила определения просроченной задачи."""

    def test_active_past_task_is_overdue(self):
        task = Task(id=1, title="Старая", due_date=TODAY - timedelta(days=1))
        self.assertTrue(task.is_overdue(TODAY))

    def test_completed_task_is_not_overdue(self):
        task = Task(id=1, title="Готово", due_date=TODAY - timedelta(days=1))
        task.status = Status.COMPLETED
        self.assertFalse(task.is_overdue(TODAY))

    def test_days_left(self):
        task = Task(id=1, title="Скоро", due_date=TODAY + timedelta(days=3))
        self.assertEqual(task.days_left(TODAY), 3)


if __name__ == "__main__":
    unittest.main()
