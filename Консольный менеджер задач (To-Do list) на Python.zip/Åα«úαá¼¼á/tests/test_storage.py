"""Тесты слоя хранения: JSON-файл, восстановление после повреждения."""

import json
import unittest
from datetime import date, datetime
from pathlib import Path

from tests.support import make_temp_folder, remove_folder
from todo.errors import StorageError
from todo.models import Priority, Status, Task
from todo.storage import JsonStorage


class StorageTestCase(unittest.TestCase):
    """Базовый класс с временной папкой для файла задач."""

    def setUp(self):
        self.folder = make_temp_folder("todo-storage-")
        self.addCleanup(remove_folder, self.folder)
        self.path = self.folder / "tasks.json"
        self.storage = JsonStorage(self.path)

    def make_task(self, task_id=1, title="Проверить отчёт"):
        return Task(
            id=task_id,
            title=title,
            description="Описание задачи",
            due_date=date(2026, 11, 20),
            priority=Priority.HIGH,
        )


class LoadTest(StorageTestCase):
    """Чтение файла задач."""

    def test_missing_file_gives_empty_list(self):
        self.assertEqual(self.storage.load(), [])

    def test_empty_file_gives_warning(self):
        self.path.write_text("", encoding="utf-8")
        self.assertEqual(self.storage.load(), [])
        self.assertTrue(self.storage.warnings)

    def test_saved_tasks_are_loaded_back(self):
        self.storage.save([self.make_task(), self.make_task(2, "Вторая")])
        tasks = self.storage.load()
        self.assertEqual([task.id for task in tasks], [1, 2])
        self.assertEqual(tasks[0].priority, Priority.HIGH)
        self.assertEqual(tasks[0].due_date, date(2026, 11, 20))
        self.assertEqual(tasks[0].status, Status.ACTIVE)

    def test_completed_status_is_restored(self):
        task = self.make_task()
        task.status = Status.COMPLETED
        task.completed_at = datetime(2026, 11, 9, 12, 30, 0)
        self.storage.save([task])
        restored = self.storage.load()[0]
        self.assertFalse(restored.is_active())
        self.assertEqual(restored.completed_at, datetime(2026, 11, 9, 12, 30))

    def test_legacy_list_format_is_supported(self):
        self.path.write_text(
            json.dumps([self.make_task().to_dict()]), encoding="utf-8"
        )
        self.assertEqual(len(self.storage.load()), 1)

    def test_corrupted_json_is_backed_up(self):
        self.path.write_text('{"tasks": [}', encoding="utf-8")
        self.assertEqual(self.storage.load(), [])
        backups = list(self.folder.glob("tasks.json.corrupted-*"))
        self.assertEqual(len(backups), 1)
        self.assertIn("повреждён", self.storage.warnings[0])

    def test_unknown_structure_is_backed_up(self):
        self.path.write_text('{"items": []}', encoding="utf-8")
        self.assertEqual(self.storage.load(), [])
        self.assertTrue(self.storage.warnings)

    def test_broken_record_is_backed_up(self):
        self.path.write_text(
            json.dumps({"tasks": [{"id": 1, "title": "Без срока"}]}),
            encoding="utf-8",
        )
        self.assertEqual(self.storage.load(), [])
        self.assertIn("due_date", self.storage.warnings[0])

    def test_directory_instead_of_file_gives_error(self):
        folder = self.folder / "tasks.json"
        folder.mkdir()
        with self.assertRaises(StorageError):
            JsonStorage(folder).load()


class SaveTest(StorageTestCase):
    """Запись файла задач."""

    def test_file_is_created_with_version(self):
        self.storage.save([self.make_task()])
        payload = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(payload["version"], 1)
        self.assertIn("saved_at", payload)
        self.assertEqual(len(payload["tasks"]), 1)

    def test_parent_folder_is_created(self):
        nested = self.folder / "data" / "nested" / "tasks.json"
        JsonStorage(nested).save([self.make_task()])
        self.assertTrue(nested.exists())

    def test_temporary_file_is_removed(self):
        self.storage.save([self.make_task()])
        self.assertEqual(list(self.folder.glob("*.tmp")), [])

    def test_cyrillic_is_written_as_utf8(self):
        self.storage.save([self.make_task(1, "Сдать отчёт")])
        text = self.path.read_text(encoding="utf-8")
        self.assertIn("Сдать отчёт", text)
        self.assertNotIn("\\u", text)

    def test_save_to_folder_gives_storage_error(self):
        folder = self.folder / "target"
        folder.mkdir()
        with self.assertRaises(StorageError):
            JsonStorage(folder).save([self.make_task()])


if __name__ == "__main__":
    unittest.main()
