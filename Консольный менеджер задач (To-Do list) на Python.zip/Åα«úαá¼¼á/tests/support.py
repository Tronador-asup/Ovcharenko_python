"""Вспомогательные функции для тестов."""

import shutil
import tempfile
import uuid
from pathlib import Path


def make_temp_folder(prefix: str = "todo-") -> Path:
    """Создать уникальную временную папку и вернуть её путь."""
    name = "%s%s" % (prefix, uuid.uuid4().hex[:8])
    folder = Path(tempfile.gettempdir()) / name
    folder.mkdir(parents=True)
    return folder


def remove_folder(folder: Path) -> None:
    """Удалить временную папку вместе с содержимым."""
    shutil.rmtree(folder, ignore_errors=True)
